# terrain router variant 15 (village->onnx; warehouse->pt; lock 12/140)
import os, sys, importlib.util
_Dx15 = os.path.dirname(os.path.abspath(__file__))
def _ldx15(n, f):
    sp = importlib.util.spec_from_file_location(n, os.path.join(_Dx15, f))
    m = importlib.util.module_from_spec(sp); sys.modules[n] = m; sp.loader.exec_module(m)
    return m.DroneFlightController
_CTx15 = {k: _ldx15("_x15_" + k, fn) for k, fn in (
    ("p003", "agent_p003.py"), ("vil", "agent_village.py"),
    ("onnx", "agent_onnx.py"), ("pt", "agent_pt.py"))}
_RTx15 = {"city": "p003", "warehouse": "pt", "forest": "onnx",
          "village": "onnx", "mountain": "pt", "open": "onnx"}
def _cpx15(o):
    try: return {k: (v.copy() if hasattr(v, "copy") else v) for k, v in o.items()}
    except Exception: return o
class DroneFlightController:
    def __init__(self, **kw):
        self._f = {k: C() for k, C in _CTx15.items()}
        self.reset()
    def reset(self):
        for a in self._f.values():
            if hasattr(a, "reset"):
                try: a.reset()
                except Exception: pass
        self._c = None; self._p = None; self._s = 0; self._t = 0
    def act(self, observation):
        self._t += 1
        if self._c is not None:
            return self._f[self._c].act(observation)
        vv = {k: _cpx15(observation) for k in self._f}
        oo = {k: self._f[k].act(vv[k]) for k in self._f}
        lab = getattr(self._f["onnx"], "_map_prediction_label", None)
        pk = _RTx15.get(lab, "p003")
        if lab is not None and lab == self._p: self._s += 1
        else: self._p = lab; self._s = 1
        if lab is not None and self._s >= 12 and self._t >= 140:
            self._c = pk
        return oo[pk]
